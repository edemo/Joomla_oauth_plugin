DROP TABLE IF EXISTS #__adalogin;
