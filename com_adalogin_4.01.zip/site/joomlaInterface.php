<?php
/**
* this method can redife in unittests
*/
class JI {
	
	public function JURI_base() {
		
	}
	
	public function JURI_root() {
		
	}
	
	public function redirect($uri, $msg) {
		
	}
	
	public function getRemoteData($object) {
		
	}
	
	public function input_get($name, $defValue, $dataType) {
		
	}
	
	public function input_set($name, $value) {
		
	}
}
?>