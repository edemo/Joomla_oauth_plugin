<div id="adalogoutScreen">
	<img src="https://adatom.hu/images/logo/adalogo_379x143.png" />
	<center>
	  <p><?php echo JText::_('ADALOGIN_ADALOGOUTMSG'); ?></p>
	</center>  
</div>

