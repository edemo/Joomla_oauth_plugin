<div id="logoutScreen">
	<img src="https://adatom.hu/images/logo/adalogo_379x143.png" />
	<center>
		  <p><?php echo JText::_('ADALOGIN_LOGOUTMSG'); ?></p>
		  <p> </p>
		  <p> </p>
		  <p>
		    <a href="<?php echo JURI::base();?>'index.php?option=com_adalogin&task=adalogout" id="adalogout">
  			  <?php echo JText::_('ADALOGIN_ADALOGOUT'); ?>
			</a>
		  </p>
	</center>  
</div>
