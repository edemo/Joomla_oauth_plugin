<?php
/**
* @version		$Id: default_viewfrontend.php 118 2012-10-02 08:52:27Z michel $
* @package		Adalogin
* @subpackage 	Views
* @copyright	Copyright (C) 2016, Fogler Tibor. All rights reserved.
* @license #GNU/GPL
*/

// no direct access
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.view');
class adaloginViewAdalogin  extends JViewLegacy {
	public function display($tpl = null) {
		parent::display($tpl);
	}
}
?>