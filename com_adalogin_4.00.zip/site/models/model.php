<?php 
/**
* @version		4.00
* @package		Adalogin
* @subpackage 	Models
* @copyright	Copyright (C) 2016, Fogler Tibor. All rights reserved.
* @license #GNU/GPL
*/
// no direct access
defined('_JEXEC') or die('Restricted access');
/**
 * Model
 * @author Michael Liebler
 */
jimport( 'joomla.application.component.model' ); 
/**
* this component not use model
*/
class AdaloginModel extends JModelLegacy  { 
}
?> 